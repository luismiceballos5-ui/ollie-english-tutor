import { SKILL_KEYS, SKILL_META } from "../constants";
import type { AppView, LevelInfo, Profile } from "../types";
import { SidebarLink } from "./SidebarLink";

export function Sidebar({
  profile,
  lvl,
  view,
  started,
  sidebarOpen,
  onClose,
  onSetView,
  onStartLesson,
}: {
  profile: Profile;
  lvl: LevelInfo;
  view: AppView;
  started: boolean;
  sidebarOpen: boolean;
  onClose: () => void;
  onSetView: (view: AppView) => void;
  onStartLesson: () => void;
}) {
  return (
    <>
      <aside
        className={`fixed md:static z-30 inset-y-0 left-0 w-64 bg-white border-r border-stone-200 flex flex-col p-4 transition-transform duration-200 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <div className="flex items-center gap-2 px-2 mb-6">
          <span className="text-2xl">🦉</span>
          <div>
            <div className="font-bold text-stone-800 leading-tight">Ollie</div>
            <div className="text-[11px] text-stone-400 leading-tight">English Tutor</div>
          </div>
        </div>

        <nav className="space-y-1 flex-1 overflow-y-auto">
          <SidebarLink
            icon="🏡"
            label="Dashboard"
            active={view === "dashboard"}
            onClick={() => {
              onSetView("dashboard");
              onClose();
            }}
          />
          <SidebarLink
            icon="🦉"
            label={started ? "Continue Lesson" : "Start Lesson"}
            active={view === "lesson"}
            onClick={() => {
              onClose();
              started ? onSetView("lesson") : onStartLesson();
            }}
          />
          <div className="pt-3 pb-1 px-3 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">
            Skills
          </div>
          {SKILL_KEYS.map((k) => (
            <div
              key={k}
              className="px-3 py-1 text-[13px] text-stone-500 flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                {SKILL_META[k].icon} {SKILL_META[k].label}
              </span>
              <span className="text-[11px] tabular-nums text-stone-400">
                {profile.skills[k]}
              </span>
            </div>
          ))}
          <div className="pt-3 pb-1 px-3 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">
            Other
          </div>
          <SidebarLink
            icon="🏆"
            label="Achievements"
            active={view === "achievements"}
            onClick={() => {
              onSetView("achievements");
              onClose();
            }}
          />
        </nav>

        <div className="pt-3 border-t border-stone-100 mt-2">
          <div className="text-[11px] text-stone-400 px-2">
            Level {lvl.level} · {profile.xp} XP
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-20 md:hidden"
          onClick={onClose}
        />
      )}
    </>
  );
}
