import { friendlyErrorMessage } from "./errors";
import type { ChatMessage } from "../types";

export interface CallAIResult {
  text: string | null;
  error: string | null;
}

/**
 * Calls our own serverless function at /api/chat, which holds the Anthropic
 * API key server-side (see api/chat.ts) and forwards the request to
 * https://api.anthropic.com/v1/messages. The browser never sees the key.
 */
export async function callAI(
  history: ChatMessage[],
  systemPrompt: string,
): Promise<CallAIResult> {
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        system: systemPrompt,
        messages: history,
      }),
    });

    let data: unknown;
    try {
      data = await res.json();
    } catch {
      return {
        text: null,
        error: "The tutor's server sent back something unreadable. Please try again.",
      };
    }

    if (!res.ok) {
      const friendly = friendlyErrorMessage(data, res.status);
      if (friendly) {
        return { text: null, error: friendly };
      }
      const msg =
        (data as { error?: { message?: string } })?.error?.message || `HTTP ${res.status}`;
      return { text: null, error: `API error: ${msg}` };
    }

    const content = (data as { content?: Array<{ type: string; text?: string }> })?.content;
    const text = Array.isArray(content)
      ? content.map((b) => (b?.type === "text" ? b.text || "" : "")).join("")
      : "";

    if (!text) {
      return {
        text: null,
        error: "Ollie didn't return any text. Please try sending that again.",
      };
    }

    return { text, error: null };
  } catch (e) {
    const message = e instanceof Error ? e.message : "could not reach the tutor.";
    return { text: null, error: `Network error: ${message}` };
  }
}
