import type { LevelInfo } from "../types";

export function levelFromXp(xp: number): LevelInfo {
  // simple curve: each level needs 20% more than the last, base 60xp
  let level = 1;
  let need = 60;
  let total = 0;
  while (xp >= total + need) {
    total += need;
    level += 1;
    need = Math.round(need * 1.2);
  }
  const into = xp - total;
  return { level, into, need };
}
