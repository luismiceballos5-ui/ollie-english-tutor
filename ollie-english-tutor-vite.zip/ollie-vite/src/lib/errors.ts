// Detects the "you've hit your usage limit" error shape and turns it into a
// short, student-friendly sentence instead of dumping raw JSON in the chat.

export function formatResetTime(iso: string): string | null {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return null;
    const diffMin = Math.round((d.getTime() - Date.now()) / 60000);
    const clock = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    if (diffMin <= 1) return `in a moment (around ${clock})`;
    if (diffMin < 60) return `in about ${diffMin} min (around ${clock})`;
    const hours = Math.round(diffMin / 60);
    return `in about ${hours} hour${hours === 1 ? "" : "s"} (around ${clock})`;
  } catch {
    return null;
  }
}

// Loosely-typed: this inspects whatever JSON body the backend proxy forwards,
// which itself just relays the Anthropic API's error/limit payload as-is.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function friendlyErrorMessage(data: any, status: number): string | null {
  const isLimitError =
    data?.type === "exceeded_limit" ||
    data?.resolved?.status === "exceeded" ||
    data?.error?.type === "rate_limit_error" ||
    status === 429;

  if (isLimitError) {
    const resetsAt = data?.resets_at || data?.resolved?.resets_at || data?.notice?.resets_at;
    const whenIso =
      typeof resetsAt === "number" ? new Date(resetsAt * 1000).toISOString() : resetsAt;
    const when = whenIso ? formatResetTime(whenIso) : null;
    return when
      ? `Ollie needs a short break — we've used up today's lesson time! Let's pick this back up ${when}. 🦉☕`
      : `Ollie needs a short break — we've used up today's lesson time! Please try again a little later. 🦉☕`;
  }

  return null;
}
