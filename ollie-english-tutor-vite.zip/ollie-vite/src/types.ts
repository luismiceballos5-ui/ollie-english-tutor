export type SkillKey =
  | "vocabulary"
  | "reading"
  | "grammar"
  | "writing"
  | "speaking"
  | "pronunciation";

export type CefrLevel = "A1" | "A2" | "B1";

export interface SkillScores {
  vocabulary: number;
  reading: number;
  grammar: number;
  writing: number;
  speaking: number;
  pronunciation: number;
}

export interface HistoryEntry {
  date: string;
  summary: string;
}

export interface Profile {
  name: string;
  level: CefrLevel;
  unitIndex: number;
  xp: number;
  streak: number;
  lastActiveDate: string | null;
  lessonsCompleted: number;
  skills: SkillScores;
  weakAreas: string[];
  achievements: string[];
  history: HistoryEntry[];
}

export type ChatRole = "user" | "assistant";

export interface ChatMessage {
  role: ChatRole;
  content: string;
}

export interface LessonPart {
  id: number;
  key: string;
  label: string;
  icon: string;
}

export interface Achievement {
  id: string;
  label: string;
  icon: string;
  desc: string;
  test: (profile: Profile) => boolean;
}

export interface ToastState {
  icon: string;
  label: string;
}

export type AppView = "dashboard" | "lesson" | "achievements";

export interface LevelInfo {
  level: number;
  into: number;
  need: number;
}
